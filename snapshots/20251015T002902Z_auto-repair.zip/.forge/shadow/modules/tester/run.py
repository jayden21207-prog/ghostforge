
def run():
    # The real runner is in forge.py; this is a stub to illustrate module layout.
    return True
