# TVPlotter — run
- kind: tv
- goal: pilot episode beat sheet

## Plan
- [tv] analyze goal: pilot episode beat sheet
- enumerate characters, arcs, episodes, motifs
- collect local data (stub; offline)
- generate structured summary

## Result
[demo] tv agent processed goal